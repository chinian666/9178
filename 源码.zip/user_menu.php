<?php
require_once 'config.php';
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'user') {
    header("Location: login.php?type=user");
    exit;
}
$username = $_SESSION['username'];
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>用户中心 - 功能菜单</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:"Microsoft YaHei",sans-serif}
body{
    background: url("http://cccimg.com/view.php/4d25a7874e08188fc0256976576489e3.jpg") no-repeat center center;
    background-size: cover;
    background-attachment: fixed;
    background-color: rgba(0,0,0,0.4);
    background-blend-mode: overlay;
    padding:30px
}
.box{max-width:500px;margin:0 auto;background:rgba(255,255,255,0.85);padding:40px;border-radius:20px;box-shadow:0 10px 30px rgba(0,0,0,0.08)}
h2{text-align:center;color:#333;margin-bottom:40px}
.menu-item{display:block;width:100%;height:60px;line-height:60px;text-align:center;background:#667eea;color:#fff;text-decoration:none;border-radius:12px;font-size:16px;margin:15px 0;transition:0.2s}
.menu-item:hover{background:#5066d8}
.logout{display:block;text-align:center;margin-top:30px;color:#667eea;text-decoration:none}
</style>
</head>
<body>
    <div class="box">
        <h2>欢迎你，<?php echo htmlspecialchars($username); ?></h2>
        <a href="user.php" class="menu-item">一、报备入口</a>
        <a href="my_order.php" class="menu-item">二、我的订单</a>
        <a href="my_wallet.php" class="menu-item">三、我的钱包</a>
        <a href="logout.php" class="logout">退出登录</a>
    </div>
</body>
</html>
