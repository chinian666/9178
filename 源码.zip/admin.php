<?php
require_once 'config.php';
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php?type=admin");
    exit;
}

// 删除单条报备
if (isset($_GET['del_id']) && is_numeric($_GET['del_id'])) {
    $delId = (int)$_GET['del_id'];
    $row = $db->query("SELECT qrcode FROM report_list WHERE id = {$delId}")->fetch(PDO::FETCH_ASSOC);
    if ($row && !empty($row['qrcode']) && file_exists($row['qrcode'])) {
        unlink($row['qrcode']);
    }
    $db->exec("DELETE FROM report_list WHERE id = {$delId}");
    header("Location: admin.php");
    exit;
}

// 一键清空所有报备
if (isset($_GET['clear']) && $_GET['clear'] === '1') {
    $qrcodeDir = "qrcodes/";
    if (is_dir($qrcodeDir)) {
        $files = glob($qrcodeDir . '*');
        foreach ($files as $f) {
            if (is_file($f)) unlink($f);
        }
    }
    $db->exec("DELETE FROM report_list");
    header("Location: admin.php");
    exit;
}

// 按用户分组统计
$groupSql = "SELECT username, SUM(price) AS user_total FROM report_list GROUP BY username ORDER BY user_total DESC";
$groupList = $db->query($groupSql)->fetchAll(PDO::FETCH_ASSOC);
$allList = $db->query("SELECT * FROM report_list ORDER BY add_time DESC")->fetchAll(PDO::FETCH_ASSOC);
$totalAll = $db->query("SELECT SUM(price) AS total_money FROM report_list")->fetch()['total_money'];
$totalAll = $totalAll ?: 0;
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>管理员后台 - 报备统计</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:"Microsoft YaHei",sans-serif}
body{
    background: url("http://cccimg.com/view.php/4d25a7874e08188fc0256976576489e3.jpg") no-repeat center center;
    background-size: cover;
    background-attachment: fixed;
    background-color: rgba(0,0,0,0.4);
    background-blend-mode: overlay;
    padding:30px
}
.box{max-width:1000px;margin:0 auto;background:rgba(255,255,255,0.85);padding:40px;border-radius:20px;box-shadow:0 10px 30px rgba(0,0,0,0.08)}
h2{text-align:center;color:#333;margin-bottom:35px}
table{width:100%;border-collapse:collapse}
th,td{border:1px solid #eee;padding:14px;text-align:center}
th{background:#f8f9ff;color:#333}
.user-group-row{background:#eef5ff;cursor:pointer;}
.user-group-row:hover{background:#e0ebff;}
.detail-row{display:none;background:#fafafa;}
.detail-table{width:100%;border-collapse:collapse;margin:0}
.detail-table td{border:1px solid #ddd;padding:10px;font-size:14px}
.total-all{margin-top:30px;padding:20px;background:#f8f9ff;border-radius:10px;font-size:18px;font-weight:bold;color:#e53935}
.operate-box{margin-top:25px;text-align:center}
.operate-btn{display:inline-block;padding:12px 30px;background:#667eea;color:#fff;text-decoration:none;border-radius:10px;margin:0 10px}
.danger-btn{background:#e53935}
.logout{display:inline-block;margin-top:25px;color:#667eea;text-decoration:none}
.empty{text-align:center;padding:30px;color:#999}
.arrow{display:inline-block;margin-right:8px;transition:.3s}
.qrcode-btn{padding:5px 10px;background:#2d8cf0;color:#fff;border:none;border-radius:4px;cursor:pointer}
.del-btn{padding:5px 10px;background:#f53f3f;color:#fff;border:none;border-radius:4px;cursor:pointer;margin-left:4px}
.modal{display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.8);justify-content:center;align-items:center;z-index:999}
.modal img{max-width:90%;max-height:90%;border-radius:8px}
.modal-close{position:absolute;top:20px;right:30px;color:#fff;font-size:30px;cursor:pointer}
</style>
</head>
<body>
    <div class="box">
        <h2>按用户统计报备金额</h2>
        <?php if (empty($groupList)): ?>
            <div class="empty">暂无任何报备记录</div>
        <?php else: ?>
        <table>
            <tr>
                <th>提交用户</th>
                <th>报备总金额(元)</th>
                <th>收款码</th>
            </tr>
            <?php foreach ($groupList as $group): ?>
            <?php $username = $group['username']; ?>
            <?php
            $userQrcode = null;
            foreach ($allList as $row) {
                if ($row['username'] === $username && !empty($row['qrcode'])) {
                    $userQrcode = $row['qrcode'];
                    break;
                }
            }
            ?>
            <tr class="user-group-row" onclick="toggleDetail('detail-<?php echo $username; ?>', this)">
                <td>
                    <span class="arrow">▶</span>
                    <?php echo htmlspecialchars($username); ?>
                </td>
                <td><?php echo number_format($group['user_total'], 2); ?></td>
                <td>
                    <?php if ($userQrcode): ?>
                        <button class="qrcode-btn" onclick="event.stopPropagation(); openModal('<?php echo $userQrcode; ?>')">查看收款码</button>
                    <?php else: ?>
                        无
                    <?php endif; ?>
                </td>
            </tr>

            <tr id="detail-<?php echo $username; ?>" class="detail-row">
                <td colspan="3">
                    <table class="detail-table">
                        <tr>
                            <td style="width:25%">报备名称</td>
                            <td style="width:15%">价格(元)</td>
                            <td style="width:25%">提交时间</td>
                            <td style="width:18%">收款码</td>
                            <td style="width:17%">操作</td>
                        </tr>
                        <?php foreach ($allList as $row): ?>
                            <?php if ($row['username'] === $username): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['report_name']); ?></td>
                                <td><?php echo $row['price']; ?></td>
                                <td><?php echo $row['add_time']; ?></td>
                                <td>
                                    <?php if (!empty($row['qrcode'])): ?>
                                        <button class="qrcode-btn" onclick="openModal('<?php echo $row['qrcode']; ?>')">查看</button>
                                    <?php else: ?>
                                        无
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="?del_id=<?php echo $row['id']; ?>" class="del-btn" onclick="return confirm('确定删除这条报备记录？删除后不可恢复！')">删除</a>
                                </td>
                            </tr>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </table>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
        <?php endif; ?>

        <div class="total-all">
            所有用户报备总金额： <?php echo number_format($totalAll, 2); ?> 元
        </div>

        <div class="operate-box">
            <a href="add_user.php" class="operate-btn">添加新用户账号</a>
            <a href="?clear=1" class="operate-btn danger-btn" onclick="return confirm('确认要清空所有报备记录吗？此操作无法恢复！')">一键清空所有报备</a>
        </div>

        <a href="logout.php" class="logout">退出登录</a>
    </div>

    <div class="modal" id="qrcodeModal">
        <span class="modal-close" onclick="closeModal()">&times;</span>
        <img id="modalImg" src="" alt="收款码">
    </div>

    <script>
    function toggleDetail(id, tr) {
        const detailRow = document.getElementById(id);
        const arrow = tr.querySelector('.arrow');
        if (detailRow.style.display === 'table-row') {
            detailRow.style.display = 'none';
            arrow.textContent = '▶';
        } else {
            detailRow.style.display = 'table-row';
            arrow.textContent = '▼';
        }
    }
    function openModal(imgSrc) {
        const modal = document.getElementById('qrcodeModal');
        const modalImg = document.getElementById('modalImg');
        modal.style.display = 'flex';
        modalImg.src = imgSrc;
    }
    function closeModal() {
        document.getElementById('qrcodeModal').style.display = 'none';
    }
    document.getElementById('qrcodeModal').addEventListener('click', function(e) {
        if (e.target === this) closeModal();
    });
    </script>
</body>
</html>
