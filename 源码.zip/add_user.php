<?php
require_once 'config.php';
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php?type=admin");
    exit;
}

$msg = '';
$msgType = '';

if ($_POST) {
    $newUser = trim($_POST['new_username']);
    $newPwd = trim($_POST['new_password']);

    if (empty($newUser) || empty($newPwd)) {
        $msg = "账号和密码不能为空！";
        $msgType = 'error';
    } else {
        $check = $db->prepare("SELECT id FROM users WHERE username = :uname");
        $check->bindParam(':uname', $newUser);
        $check->execute();
        if ($check->fetch()) {
            $msg = "该账号已存在，请更换！";
            $msgType = 'error';
        } else {
            $pwdMd5 = md5($newPwd);
            $insert = $db->prepare("INSERT INTO users (username, password, role) VALUES (:uname, :pwd, 'user')");
            $insert->bindParam(':uname', $newUser);
            $insert->bindParam(':pwd', $pwdMd5);
            $insert->execute();
            $msg = "用户【{$newUser}】创建成功！初始密码：{$newPwd}";
            $msgType = 'success';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>管理员 - 添加用户</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:"Microsoft YaHei",sans-serif}
body{
    background: url("http://cccimg.com/view.php/4d25a7874e08188fc0256976576489e3.jpg") no-repeat center center;
    background-size: cover;
    background-attachment: fixed;
    background-color: rgba(0,0,0,0.4);
    background-blend-mode: overlay;
    padding:30px
}
.box{max-width:500px;margin:0 auto;background:rgba(255,255,255,0.85);padding:40px;border-radius:20px;box-shadow:0 10px 30px rgba(0,0,0,0.08)}
h2{text-align:center;color:#333;margin-bottom:35px}
.item{margin:20px 0}
label{display:block;margin-bottom:8px;color:#555}
input{width:100%;height:50px;padding:0 15px;border:1px solid #eee;border-radius:10px;font-size:15px}
.btn{width:100%;height:50px;background:#667eea;color:#fff;border:none;border-radius:10px;font-size:16px;cursor:pointer;margin-top:15px}
.back{display:block;text-align:center;margin-top:25px;color:#667eea;text-decoration:none}
.success{text-align:center;margin:15px 0;color:green;}
.error{text-align:center;margin:15px 0;color:red;}
</style>
</head>
<body>
    <div class="box">
        <h2>手动添加用户账号</h2>
        <?php if (!empty($msg)): ?>
            <div class="<?php echo $msgType; ?>"><?php echo $msg; ?></div>
        <?php endif; ?>
        <form method="post">
            <div class="item">
                <label>新用户账号</label>
                <input type="text" name="new_username" placeholder="请设置用户账号" required>
            </div>
            <div class="item">
                <label>登录密码</label>
                <input type="text" name="new_password" placeholder="请设置登录密码" required>
            </div>
            <button class="btn" type="submit">确认创建账号</button>
        </form>
        <a href="admin.php" class="back">返回报备统计页面</a>
    </div>
</body>
</html>
