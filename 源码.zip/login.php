<?php
require_once 'config.php';
$type = $_GET['type'] ?? 'user';
$msg = '';

if ($_POST) {
    $username = trim($_POST['username']);
    $pwd = md5(trim($_POST['password']));

    $sql = "SELECT * FROM users WHERE username = :name AND password = :pwd";
    $stmt = $db->prepare($sql);
    $stmt->bindParam(':name', $username);
    $stmt->bindParam(':pwd', $pwd);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        if ($user['role'] === 'admin') {
            header("Location: admin.php");
        } else {
            header("Location: user_menu.php");
        }
        exit;
    } else {
        $msg = "账号或密码错误！";
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo $type == 'admin' ? '管理员登录' : '用户登录'; ?></title>
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:"Microsoft YaHei",sans-serif}
body{
    background: url("http://cccimg.com/view.php/4d25a7874e08188fc0256976576489e3.jpg") no-repeat center center;
    background-size: cover;
    background-attachment: fixed;
    background-color: rgba(0,0,0,0.4);
    background-blend-mode: overlay;
    min-height:100vh;display:flex;justify-content:center;align-items:center;padding:20px
}
.login-box{width:100%;max-width:420px;background:rgba(255,255,255,0.85);padding:40px;border-radius:20px;box-shadow:0 20px 40px rgba(0,0,0,0.1)}
h2{text-align:center;color:#333;margin-bottom:30px}
input{width:100%;height:50px;padding:0 15px;margin:12px 0;border:1px solid #eee;border-radius:10px;font-size:15px;outline:none}
input:focus{border-color:#667eea}
.btn{width:100%;height:50px;background:#667eea;color:#fff;border:none;border-radius:10px;font-size:16px;cursor:pointer;margin-top:10px}
.back{display:block;text-align:center;margin-top:20px;color:#667eea;text-decoration:none}
.error{color:red;text-align:center;margin:10px 0;}
</style>
</head>
<body>
    <div class="login-box">
        <h2><?php echo $type == 'admin' ? '管理员登录' : '用户登录'; ?></h2>
        <?php if ($msg): ?>
            <div class="error"><?php echo $msg; ?></div>
        <?php endif; ?>
        <form method="post">
            <input type="text" name="username" placeholder="请输入账号" required>
            <input type="password" name="password" placeholder="请输入密码" required>
            <button class="btn" type="submit">登录</button>
        </form>
        <a href="index.php" class="back">返回首页</a>
    </div>
</body>
</html>
