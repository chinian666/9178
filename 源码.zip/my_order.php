<?php
require_once 'config.php';
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'user') {
    header("Location: login.php?type=user");
    exit;
}
$username = $_SESSION['username'];

$list = $db->prepare("SELECT * FROM report_list WHERE username = :user ORDER BY add_time DESC");
$list->bindParam(':user', $username);
$list->execute();
$myList = $list->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>我的订单</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:"Microsoft YaHei",sans-serif}
body{
    background: url("http://cccimg.com/view.php/4d25a7874e08188fc0256976576489e3.jpg") no-repeat center center;
    background-size: cover;
    background-attachment: fixed;
    background-color: rgba(0,0,0,0.4);
    background-blend-mode: overlay;
    padding:30px
}
.box{max-width:800px;margin:0 auto;background:rgba(255,255,255,0.85);padding:40px;border-radius:20px;box-shadow:0 10px 30px rgba(0,0,0,0.08)}
h2{text-align:center;color:#333;margin-bottom:35px}
table{width:100%;border-collapse:collapse}
th,td{border:1px solid #eee;padding:12px;text-align:center;font-size:14px}
th{background:#f8f9ff}
.empty{text-align:center;padding:40px;color:#999}
.back-menu{display:block;text-align:center;margin-top:25px;color:#667eea;text-decoration:none}
.qrcode-btn{padding:4px 8px;background:#2d8cf0;color:#fff;border:none;border-radius:4px;cursor:pointer}
.modal{display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.8);justify-content:center;align-items:center;z-index:999}
.modal img{max-width:90%;max-height:90%}
.modal-close{position:absolute;top:20px;right:30px;color:#fff;font-size:30px;cursor:pointer}
</style>
</head>
<body>
    <div class="box">
        <h2>我的报备订单</h2>
        <?php if (empty($myList)): ?>
            <div class="empty">暂无报备记录</div>
        <?php else: ?>
        <table>
            <tr>
                <th>报备名称</th>
                <th>金额(元)</th>
                <th>提交时间</th>
                <th>收款码</th>
            </tr>
            <?php foreach ($myList as $row): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['report_name']); ?></td>
                <td><?php echo $row['price']; ?></td>
                <td><?php echo $row['add_time']; ?></td>
                <td>
                    <?php if (!empty($row['qrcode'])): ?>
                        <button class="qrcode-btn" onclick="openModal('<?php echo $row['qrcode']; ?>')">查看</button>
                    <?php else: ?>
                        无
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
        <?php endif; ?>
        <a href="user_menu.php" class="back-menu">返回功能菜单</a>
    </div>

    <div class="modal" id="qrcodeModal">
        <span class="modal-close" onclick="closeModal()">&times;</span>
        <img id="modalImg" src="" alt="收款码">
    </div>

    <script>
    function openModal(src){
        document.getElementById('modalImg').src = src;
        document.getElementById('qrcodeModal').style.display = 'flex';
    }
    function closeModal(){
        document.getElementById('qrcodeModal').style.display = 'none';
    }
    document.getElementById('qrcodeModal').addEventListener('click',function(e){
        if(e.target === this) closeModal();
    });
    </script>
</body>
</html>
