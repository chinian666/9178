<?php
session_start();
// 连接SQLite数据库
try {
    $db = new PDO('sqlite:club_data.db');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("数据库连接失败：" . $e->getMessage());
}

// 创建用户表
$db->exec("CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'user',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP
)");

// 创建报备记录表
$db->exec("CREATE TABLE IF NOT EXISTS report_list (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL,
    report_name TEXT NOT NULL,
    price REAL NOT NULL,
    qrcode TEXT NULL,
    add_time DATETIME DEFAULT CURRENT_TIMESTAMP
)");

// 新增qrcode字段（已存在则忽略）
try {
    $db->exec("ALTER TABLE report_list ADD COLUMN qrcode TEXT NULL");
} catch (Exception $e) {}

// 初始化默认管理员账号 admin / 123456
$adminCheck = $db->query("SELECT * FROM users WHERE username = 'admin'")->fetch();
if (!$adminCheck) {
    $initPwd = md5("123456");
    $db->exec("INSERT INTO users (username, password, role) VALUES ('admin', '$initPwd', 'admin')");
}
?>
