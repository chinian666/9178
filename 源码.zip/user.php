<?php
require_once 'config.php';
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'user') {
    header("Location: login.php?type=user");
    exit;
}
$username = $_SESSION['username'];
$msg = '';
$uploadPath = "qrcodes/";
if (!file_exists($uploadPath)) {
    mkdir($uploadPath, 0777, true);
}

if ($_POST) {
    $reportName = trim($_POST['report_name']);
    $price = floatval($_POST['price']);
    $qrcodePath = null;

    if (isset($_FILES['qrcode']) && $_FILES['qrcode']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['qrcode']['tmp_name'];
        $fileName = $_FILES['qrcode']['name'];
        $fileNameCmps = explode(".", $fileName);
        $fileExtension = strtolower(end($fileNameCmps));
        $allowedExts = ['jpg', 'jpeg', 'png', 'gif'];
        if (in_array($fileExtension, $allowedExts)) {
            $newFileName = $username . '_' . time() . '.' . $fileExtension;
            $destPath = $uploadPath . $newFileName;
            if (move_uploaded_file($fileTmpPath, $destPath)) {
                $qrcodePath = $destPath;
            } else {
                $msg = "图片上传失败！";
            }
        } else {
            $msg = "仅支持 jpg / png / gif 格式图片";
        }
    }

    if (empty($reportName) || $price <= 0) {
        $msg = "报备名称不能为空，金额必须大于0！";
    } else {
        $sql = "INSERT INTO report_list (username, report_name, price, qrcode) VALUES (:user, :rname, :price, :qrcode)";
        $stmt = $db->prepare($sql);
        $stmt->bindParam(':user', $username);
        $stmt->bindParam(':rname', $reportName);
        $stmt->bindParam(':price', $price);
        $stmt->bindParam(':qrcode', $qrcodePath);
        $stmt->execute();
        $msg = "报备提交成功！";
        header("Refresh:3; url=user_menu.php");
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>报备入口</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:"Microsoft YaHei",sans-serif}
body{
    background: url("http://cccimg.com/view.php/4d25a7874e08188fc0256976576489e3.jpg") no-repeat center center;
    background-size: cover;
    background-attachment: fixed;
    background-color: rgba(0,0,0,0.4);
    background-blend-mode: overlay;
    padding:30px
}
.box{max-width:500px;margin:0 auto;background:rgba(255,255,255,0.85);padding:40px;border-radius:20px;box-shadow:0 10px 30px rgba(0,0,0,0.08)}
h2{text-align:center;color:#333;margin-bottom:35px}
.item{margin:20px 0}
label{display:block;margin-bottom:8px;color:#555}
input{width:100%;height:50px;padding:0 15px;border:1px solid #eee;border-radius:10px;font-size:15px}
.btn{width:100%;height:50px;background:#667eea;color:#fff;border:none;border-radius:10px;font-size:16px;cursor:pointer;margin-top:15px}
.back-menu{display:block;text-align:center;margin-top:25px;color:#667eea;text-decoration:none}
.tip{text-align:center;margin:15px 0;color:green;}
.error{text-align:center;margin:15px 0;color:red;}
input[type="file"]{padding:10px 0;}
</style>
</head>
<body>
    <div class="box">
        <h2>新建报备</h2>
        <?php if ($msg): ?>
            <div class="<?php echo str_contains($msg,'成功') ? 'tip' : 'error'; ?>">
                <?php echo $msg; ?>
                <?php if (str_contains($msg,'成功')): ?>
                    <br><small>3秒后自动返回菜单...</small>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        <form method="post" enctype="multipart/form-data">
            <div class="item">
                <label>报备名称</label>
                <input type="text" name="report_name" placeholder="请填写报备名称" required>
            </div>
            <div class="item">
                <label>报备价格（元）</label>
                <input type="number" step="0.01" name="price" placeholder="请填写金额" required>
            </div>
            <div class="item">
                <label>上传收款码（可选）</label>
                <input type="file" name="qrcode" accept="image/*">
            </div>
            <button class="btn" type="submit">提交报备</button>
        </form>
        <a href="user_menu.php" class="back-menu">返回功能菜单</a>
    </div>
</body>
</html>
