<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>念酱报备系统</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:"Microsoft YaHei",sans-serif}
body{
    background: url("http://cccimg.com/view.php/4d25a7874e08188fc0256976576489e3.jpg") no-repeat center center;
    background-size: cover;
    background-attachment: fixed;
    background-color: rgba(0,0,0,0.4);
    background-blend-mode: overlay;
    min-height:100vh;display:flex;justify-content:center;align-items:center;padding:20px
}
.container{width:100%;max-width:900px;background:rgba(255,255,255,0.85);border-radius:20px;padding:50px 30px;box-shadow:0 20px 40px rgba(0,0,0,0.1);text-align:center}
.title{font-size:32px;font-weight:700;color:#333;margin-bottom:10px}
.subtitle{font-size:16px;color:#666;margin-bottom:50px}
.card-box{display:flex;justify-content:center;gap:30px;flex-wrap:wrap;margin-bottom:60px}
.card{width:260px;padding:40px 20px;border-radius:15px;background:#f8f9ff;border:1px solid #eee;transition:.3s;cursor:pointer;text-decoration:none;color:inherit}
.card:hover{transform:translateY(-5px);box-shadow:0 10px 25px rgba(102,126,234,0.15)}
.card-icon{font-size:40px;margin-bottom:20px;color:#667eea}
.card-title{font-size:18px;font-weight:700;color:#333;margin-bottom:10px}
.card-desc{font-size:14px;color:#666;line-height:1.5}
</style>
</head>
<body>
<div class="container">
    <h1 class="title">念酱报备系统</h1>
    <p class="subtitle">专业的报备与结算管理平台</p>

    <div class="card-box">
        <a href="login.php?type=user" class="card">
            <div class="card-icon">👤</div>
            <div class="card-title">用户入口</div>
            <div class="card-desc">提交报备 · 查看记录</div>
        </a>
        <a href="login.php?type=admin" class="card">
            <div class="card-icon">📋</div>
            <div class="card-title">管理员入口</div>
            <div class="card-desc">查看报备 · 金额统计</div>
        </a>
    </div>
</div>
</body>
</html>
