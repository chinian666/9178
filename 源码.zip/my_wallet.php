<?php
require_once 'config.php';
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'user') {
    header("Location: login.php?type=user");
    exit;
}
$username = $_SESSION['username'];

$sumSql = "SELECT SUM(price) AS total FROM report_list WHERE username = :user";
$stmt = $db->prepare($sumSql);
$stmt->bindParam(':user', $username);
$stmt->execute();
$res = $stmt->fetch();
$totalMoney = $res['total'] ?? 0;
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>我的钱包</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:"Microsoft YaHei",sans-serif}
body{
    background: url("http://cccimg.com/view.php/4d25a7874e08188fc0256976576489e3.jpg") no-repeat center center;
    background-size: cover;
    background-attachment: fixed;
    background-color: rgba(0,0,0,0.4);
    background-blend-mode: overlay;
    padding:30px
}
.box{max-width:500px;margin:0 auto;background:rgba(255,255,255,0.85);padding:60px 40px;border-radius:20px;box-shadow:0 10px 30px rgba(0,0,0,0.08);text-align:center}
h2{color:#333;margin-bottom:40px}
.money{font-size:48px;color:#e53935;font-weight:bold;margin:30px 0}
.desc{color:#666;font-size:16px}
.back-menu{display:inline-block;margin-top:40px;color:#667eea;text-decoration:none}
</style>
</head>
<body>
    <div class="box">
        <h2>我的钱包</h2>
        <div class="desc">当前累计报备总金额</div>
        <div class="money"><?php echo number_format($totalMoney, 2); ?> 元</div>
        <a href="user_menu.php" class="back-menu">返回功能菜单</a>
    </div>
</body>
</html>
